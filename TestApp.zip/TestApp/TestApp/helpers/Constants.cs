﻿namespace ShoppingBasket.helpers
{
    static class Constants
    {
        public const decimal maxWeight = 20m;
    }
}
