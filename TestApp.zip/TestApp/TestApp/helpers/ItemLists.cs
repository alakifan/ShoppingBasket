﻿using System.Collections.Generic;
using ShoppingBasket.models;

namespace ShoppingBasket.helpers
{
    internal static class ItemLists
    {
        public static readonly List<Item> availableItems = new List<Item>
        {
            new Item { Name="KitKat", Weight=0.2m, Quantity=16 },
            new Item { Name="Coke", Weight=0.4m, Quantity=11 },
            new Item { Name="Milk", Weight=1.1m, Quantity=6 },
            new Item { Name="Nestea", Weight=0.6m, Quantity=14 },
            new Item { Name="Beer", Weight=1.3m, Quantity=9 },
            new Item { Name="Wine", Weight=0.9m, Quantity=8 },
            new Item { Name="Ice", Weight=1m, Quantity=10 },
            new Item { Name="Pizza", Weight=0.5m, Quantity=15 },
            new Item { Name="Oil", Weight=3.2m, Quantity=5 },
            new Item { Name="Soap", Weight=2m, Quantity=7 }
        };

        public static readonly List<Item> perfectShoppingList = new List<Item>
        {
            new Item { Name="Beer", Weight=1.3m, Quantity=2 },
            new Item { Name="KitKat", Weight=0.2m, Quantity=1 },
            new Item { Name="Nestea", Weight=0.6m, Quantity=2 },
            new Item { Name="Oil", Weight=3.2m, Quantity=5 }
        };

        public static readonly List<Item> excessiveShoppingList = new List<Item>
        {
            new Item { Name="Beer", Weight=1.3m, Quantity=2 },
            new Item { Name="KitKat", Weight=0.2m, Quantity=2 },
            new Item { Name="Nestea", Weight=0.6m, Quantity=2 },
            new Item { Name="Oil", Weight=3.2m, Quantity=5 }
        };

        public static readonly List<Item> veryExcessiveShoppingList = new List<Item>
        {
            new Item { Name="Shovel", Weight=10m, Quantity=1 },
            new Item { Name="Beer", Weight=1.3m, Quantity=2 },
            new Item { Name="KitKat", Weight=0.2m, Quantity=12 },
            new Item { Name="Nestea", Weight=0.6m, Quantity=12 },
            new Item { Name="Coke", Weight=0.4m, Quantity=1 },
            new Item { Name="Oil", Weight=3.2m, Quantity=6 }
        };
    }
}
