﻿using ShoppingBasket.models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ShoppingBasket.helpers
{
    internal class ItemHelpers
    {
        public static List<Item> SortItemListByWeight(List<Item> list)
        {
            return list.OrderByDescending(item => item.Weight).ToList();
        }

        public static List<Item> LoadShoppingBasket(List<Item> list)
        {
            var shoppingBasket = new List<Item>();
            var currentWeight = 0m;

            foreach (var item in list)
            {
                //Check if the item on the list is available
                var stockItem = ItemLists.availableItems.FirstOrDefault(i => i.Name == item.Name);
                if (stockItem == null || stockItem.Quantity == 0)
                {
                    Console.WriteLine("Removed item: " + item.Name + "\t Reason: not available");
                    continue;
                }

                //Check how many items can and will be added to the basket, based on weight, quantity and availability
                var maxItemsAllowed = (int)((Constants.maxWeight - currentWeight) / item.Weight);
                var itemsToAdd = Math.Min(maxItemsAllowed, item.Quantity);
                itemsToAdd = Math.Min(itemsToAdd, stockItem.Quantity);

                //Add item to basket and update its current weight
                if (itemsToAdd > 0)
                {
                    item.Quantity = itemsToAdd;
                    shoppingBasket.Add(item);
                    currentWeight += item.Weight * itemsToAdd;
                }
                else
                {
                    Console.WriteLine("Removed item: " + item.Name + "\t Reason: weight exceeded");
                }
            }
            return shoppingBasket;
        }
    }
}
