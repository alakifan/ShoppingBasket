﻿namespace ShoppingBasket.models
{
    internal class Item
    {
        public string Name { get; set; }
        public decimal Weight { get; set; }
        public int Quantity { get; set; }

        public override string ToString()
        {
            return Name + "\t\t" + Weight + "Kg" + "\t\t" + Quantity + " Unit(s)";
        }
    }
}