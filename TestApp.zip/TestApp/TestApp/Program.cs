﻿using ShoppingBasket.helpers;
using ShoppingBasket.models;
using System;
using System.Collections.Generic;

namespace ShoppingBasket
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("Please choose from one of these test lists:");
            Console.WriteLine("1 -> Perfect list");
            Console.WriteLine("2 -> Excessive list");
            Console.WriteLine("3 -> Very excessive and wrong list");

            var sortedList = new List<Item>();
            bool validChoice;
            do
            {
                validChoice = true;
                Console.WriteLine("Please input the number of your chosen list:");
                string chosenList = Console.ReadLine();
                int.TryParse(chosenList, out int result);

                switch (result)
                {
                    case 1:
                        sortedList = SortChosenList(ItemLists.perfectShoppingList);
                        break;
                    case 2:
                        sortedList = SortChosenList(ItemLists.excessiveShoppingList);
                        break;
                    case 3:
                        sortedList = SortChosenList(ItemLists.veryExcessiveShoppingList);
                        break;
                    default:
                        validChoice = false;
                        Console.WriteLine("You can do better than that, come on ;)");
                        break;
                }
            } while (!validChoice);

            Console.WriteLine("\n--- Final list ---");
            foreach (var item in ItemHelpers.LoadShoppingBasket(sortedList))
            {
                Console.WriteLine(item.ToString());
            }
        }

        private static List<Item> SortChosenList(List<Item> list)
        {
            Console.WriteLine("Chosen list:");
            foreach (var item in list)
            {
                Console.WriteLine(item.ToString());
            }
            Console.WriteLine("\nSorted list:");
            var sortedList = ItemHelpers.SortItemListByWeight(list);
            foreach (var item in sortedList)
            {
                Console.WriteLine(item.ToString());
            }
            return sortedList;
        }
    }
}